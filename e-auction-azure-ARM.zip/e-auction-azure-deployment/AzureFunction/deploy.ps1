Connect-AzAccount
Set-AzContext -SubscriptionID "90ce919d-2b2e-413e-a316-5a10fc438494"
New-AzResourceGroup -Name rg-hackfse-eauctionapp -Location "South India"
New-AzResourceGroupDeployment -Name HackFSEDeployment -ResourceGroupName rg-hackfse-eauctionapp -TemplateFile ./azuredeploy.json -TemplateParameterFile ./azuredeploy.parameters.json